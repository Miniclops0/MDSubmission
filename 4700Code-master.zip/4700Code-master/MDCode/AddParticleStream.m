function [ output_args ] = AddParticleStream(num, x0, y0, PartAng, Type, Ep, Seper)
global AtomSpacing x y AtomType Vx Vy Mass0 Mass1 nAtoms

r_n = rand(1,1);

Mass = (Mass1 + (Mass0- Mass1))*r_n; % Random mass, standard matlab implementation for random variable within 2 bounds.

for p = 0:num - 1
    nAtoms = nAtoms + 1;
    x(nAtoms) = x0 * AtomSpacing - Seper * p * AtomSpacing * cos(PartAng);
    y(nAtoms) = y0 * AtomSpacing - Seper * p * AtomSpacing * sin(PartAng);
    AtomType(nAtoms) = Type;
end

V = 5 * sqrt(2 * Ep / Mass); % Sped it up by a magnitude of 5

for p = 1:num %edited it so that each particle is shot from a different angle
    if p < 2
        Vx(nAtoms - num + p) = V * cos(PartAng - 0.5/p); 
        Vy(nAtoms - num + p) = V * sin(PartAng);
    else
        Vx(nAtoms - num + p) = V * cos(PartAng + 0.05*p);
        Vy(nAtoms - num + p) = V * sin(PartAng);
    end
end

end
