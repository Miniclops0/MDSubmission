function [ U ] = Pot_const(x, paras)

a = paras(1);
U = a;

end
